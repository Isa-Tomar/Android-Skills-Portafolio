package com.example.androidskillsportafolio;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class ActivityEjercicio8 extends AppCompatActivity {

    private EditText etBase, etExponente;
    private TextView tvResultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ejercicio8);

        // Inicializar vistas
        etBase = findViewById(R.id.etBase);
        etExponente = findViewById(R.id.etExponente);
        tvResultado = findViewById(R.id.tvResultado);
        Button btnCalcular = findViewById(R.id.btnCalcular);
        Button btnBack = findViewById(R.id.btnBack);

        // Configurar listeners
        btnCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calcularPotencia();
            }
        });

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private void calcularPotencia() {
        try {
            // Validar campos vacíos
            if (etBase.getText().toString().isEmpty() || etExponente.getText().toString().isEmpty()) {
                Toast.makeText(this, "Por favor complete ambos campos", Toast.LENGTH_SHORT).show();
                return;
            }

            // Obtener valores
            double base = Double.parseDouble(etBase.getText().toString());
            double exponente = Double.parseDouble(etExponente.getText().toString());

            // Calcular potencia
            double resultado = Math.pow(base, exponente);

            // Mostrar resultado formateado
            String resultadoFormateado;
            if (resultado == (long) resultado) {
                resultadoFormateado = String.format("%,.0f", resultado);
            } else {
                resultadoFormateado = String.format("%,.4f", resultado);
            }

            tvResultado.setText(base + "^" + exponente + " = " + resultadoFormateado);

        } catch (NumberFormatException e) {
            Toast.makeText(this, "Ingrese valores numéricos válidos", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Error en el cálculo", Toast.LENGTH_SHORT).show();
        }
    }
}