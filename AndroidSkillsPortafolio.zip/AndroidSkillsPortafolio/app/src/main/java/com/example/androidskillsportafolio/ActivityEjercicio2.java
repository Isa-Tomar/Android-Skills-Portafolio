package com.example.androidskillsportafolio;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class ActivityEjercicio2 extends AppCompatActivity {

    private EditText etTexto1, etTexto2;
    private TextView tvTexto1, tvTexto2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ejercicio2);

        etTexto1 = findViewById(R.id.etTexto1);
        etTexto2 = findViewById(R.id.etTexto2);
        tvTexto1 = findViewById(R.id.tvTexto1);
        tvTexto2 = findViewById(R.id.tvTexto2);

        // Botones - Nota el cambio de "btnTraspasa" a "btnTraspasa" (con una 's')
        Button btnTraspasa1 = findViewById(R.id.btnTraspasa1);
        Button btnTraspasa2 = findViewById(R.id.btnTraspasa2);
        Button btnBack = findViewById(R.id.btnBack);

        // Configurar listeners
        btnTraspasa1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String texto = etTexto1.getText().toString();
                tvTexto1.setText(texto);
            }
        });

        btnTraspasa2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String texto = etTexto2.getText().toString();
                tvTexto2.setText(texto);
            }
        });

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}