package com.example.androidskillsportafolio;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class ActivityEjercicio9 extends AppCompatActivity {

    private EditText etCoefA, etCoefB, etCoefC;
    private TextView tvResultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ejercicio9);

        // Inicializar vistas
        etCoefA = findViewById(R.id.etCoefA);
        etCoefB = findViewById(R.id.etCoefB);
        etCoefC = findViewById(R.id.etCoefC);
        tvResultado = findViewById(R.id.tvResultado);
        Button btnCalcular = findViewById(R.id.btnCalcular);
        Button btnBack = findViewById(R.id.btnBack);

        // Configurar listeners
        btnCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calcularEcuacionCuadratica();
            }
        });

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private void calcularEcuacionCuadratica() {
        try {
            // Validar campos vacíos
            if (etCoefA.getText().toString().isEmpty() ||
                    etCoefB.getText().toString().isEmpty() ||
                    etCoefC.getText().toString().isEmpty()) {
                Toast.makeText(this, "Por favor complete todos los coeficientes", Toast.LENGTH_SHORT).show();
                return;
            }

            // Obtener valores
            double a = Double.parseDouble(etCoefA.getText().toString());
            double b = Double.parseDouble(etCoefB.getText().toString());
            double c = Double.parseDouble(etCoefC.getText().toString());

            // Validar que 'a' no sea cero
            if (a == 0) {
                tvResultado.setText("El coeficiente 'a' no puede ser cero (no es ecuación cuadrática)");
                return;
            }

            // Calcular discriminante
            double discriminante = b * b - 4 * a * c;
            String resultado;

            if (discriminante < 0) {
                // Soluciones complejas
                double parteReal = -b / (2 * a);
                double parteImag = Math.sqrt(-discriminante) / (2 * a);
                resultado = String.format("Soluciones complejas:\nx₁ = %.2f + %.2fi\nx₂ = %.2f - %.2fi",
                        parteReal, parteImag, parteReal, parteImag);
            }
            else if (discriminante == 0) {
                // Solución única
                double x = -b / (2 * a);
                resultado = String.format("Solución real única:\nx = %.4f", x);
            }
            else {
                // Dos soluciones reales
                double x1 = (-b + Math.sqrt(discriminante)) / (2 * a);
                double x2 = (-b - Math.sqrt(discriminante)) / (2 * a);
                resultado = String.format("Dos soluciones reales:\nx₁ = %.4f\nx₂ = %.4f", x1, x2);
            }

            tvResultado.setText(resultado);

        } catch (NumberFormatException e) {
            Toast.makeText(this, "Ingrese valores numéricos válidos", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Error en el cálculo", Toast.LENGTH_SHORT).show();
        }
    }
}