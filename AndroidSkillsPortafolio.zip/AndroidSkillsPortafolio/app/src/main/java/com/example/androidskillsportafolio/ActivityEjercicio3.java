package com.example.androidskillsportafolio;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class ActivityEjercicio3 extends AppCompatActivity {

    private EditText etTexto;
    private TextView tvTextoMostrado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ejercicio3);

        // Inicializar vistas
        etTexto = findViewById(R.id.etTexto);
        tvTextoMostrado = findViewById(R.id.tvTextoMostrado);
        Button btnVaciar = findViewById(R.id.btnVaciar);
        Button btnBack = findViewById(R.id.btnBack);

        // Listener para cambios en el texto (equivalente a keyReleased)
        etTexto.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                tvTextoMostrado.setText(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        // Listener para el botón Vaciar
        btnVaciar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                etTexto.setText("");
                tvTextoMostrado.setText("");
            }
        });

        // Listener para el botón Regresar
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}