package com.example.androidskillsportafolio;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class ActivityEjercicio10 extends AppCompatActivity {

    private Spinner cmbSO;
    private Button btnMostrar;
    private TextView lblMensaje;

    private Button btnRegresar;

    // Lista de Sistemas Operativos
    private String[] sistemasOperativos = {"Windows", "macOs", "Linux", "Android", "iOS"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ejercicio10);

        // Referenciar los elementos del XML
        cmbSO = findViewById(R.id.cmbSO);
        btnMostrar = findViewById(R.id.btnMostrar);
        lblMensaje = findViewById(R.id.lblMensaje);
        Button btnRegresar = findViewById(R.id.btnRegresar);

        // Adaptador para el Spinner
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_item,
                sistemasOperativos
        );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        cmbSO.setAdapter(adapter);

        // Listener cuando se selecciona un item del Spinner
        cmbSO.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String seleccion = sistemasOperativos[position];
                lblMensaje.setText("Seleccionaste: " + seleccion);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                lblMensaje.setText("No seleccionaste ningún sistema operativo.");
            }
        });
        btnRegresar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        // Acción del botón
        btnMostrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (cmbSO.getCount() == 0) {
                    Toast.makeText(ActivityEjercicio10.this,
                            "No hay sistemas operativos disponibles.",
                            Toast.LENGTH_LONG).show();
                    return;
                }

                String seleccionado = (String) cmbSO.getSelectedItem();
                if (seleccionado != null) {
                    lblMensaje.setText("Seleccionaste: " + seleccionado);
                } else {
                    lblMensaje.setText("No seleccionaste ningún sistema operativo.");
                }
            }
        });
    }
}


