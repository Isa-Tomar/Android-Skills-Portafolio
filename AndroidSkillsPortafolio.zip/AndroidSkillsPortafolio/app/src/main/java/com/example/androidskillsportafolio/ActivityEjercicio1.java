package com.example.androidskillsportafolio;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class ActivityEjercicio1 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ejercicio1);

        // Obtener referencias a las vistas
        final TextView lblNombre = findViewById(R.id.lblNombre);
        final TextView lblCiudad = findViewById(R.id.lblCiudad);
        Button btnOcultarNombre = findViewById(R.id.btnOcultarNombre);
        Button btnVisuNombre = findViewById(R.id.btnVisuNombre);
        Button btnOcultarCiudad = findViewById(R.id.btnOcultarCiudad);
        Button btnVisuCiudad = findViewById(R.id.btnVisuCiudad);
        Button btnBack = findViewById(R.id.btnBack);

        // Configurar eventos
        btnOcultarNombre.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                lblNombre.setVisibility(View.INVISIBLE);
            }
        });

        btnVisuNombre.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                lblNombre.setVisibility(View.VISIBLE);
            }
        });

        btnOcultarCiudad.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                lblCiudad.setVisibility(View.INVISIBLE);
            }
        });

        btnVisuCiudad.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                lblCiudad.setVisibility(View.VISIBLE);
            }
        });

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish(); // Cierra esta actividad
            }
        });
    }
}