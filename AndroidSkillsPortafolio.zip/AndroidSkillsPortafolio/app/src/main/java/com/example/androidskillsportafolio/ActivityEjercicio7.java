package com.example.androidskillsportafolio;

import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class ActivityEjercicio7 extends AppCompatActivity {

    private EditText etRadio;
    private TextView tvArea, tvPerimetro;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ejercicio7);

        // Inicializar vistas
        etRadio = findViewById(R.id.etRadio);
        tvArea = findViewById(R.id.tvArea);
        tvPerimetro = findViewById(R.id.tvPerimetro);
        Button btnBack = findViewById(R.id.btnBack);

        // Listener para cambios en el texto (cálculo automático)
        etRadio.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                calcularCirculo();
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        // Listener para el botón Regresar
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private void calcularCirculo() {
        try {
            if (etRadio.getText().toString().isEmpty()) {
                tvArea.setText("Área:");
                tvPerimetro.setText("Perímetro:");
                return;
            }

            double radio = Double.parseDouble(etRadio.getText().toString());

            if (radio < 0) {
                tvArea.setText("Área: Error - Radio negativo");
                tvPerimetro.setText("Perímetro: Error - Radio negativo");
                tvArea.setTextColor(Color.RED);
                tvPerimetro.setTextColor(Color.RED);
            } else {
                double area = Math.PI * radio * radio;
                double perimetro = 2 * Math.PI * radio;

                tvArea.setText(String.format("Área: %.4f", area));
                tvPerimetro.setText(String.format("Perímetro: %.4f", perimetro));
                tvArea.setTextColor(Color.BLACK);
                tvPerimetro.setTextColor(Color.BLACK);
            }
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Ingrese un valor numérico válido", Toast.LENGTH_SHORT).show();
        }
    }
}