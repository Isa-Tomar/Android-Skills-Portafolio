package com.example.androidskillsportafolio;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class ActivityEjercicio4 extends AppCompatActivity {

    private EditText etNombre, etCiudad;
    private TextView tvFrase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ejercicio4);

        // Inicializar vistas
        etNombre = findViewById(R.id.etNombre);
        etCiudad = findViewById(R.id.etCiudad);
        tvFrase = findViewById(R.id.tvFrase);
        Button btnAceptar = findViewById(R.id.btnAceptar);
        Button btnDesactivar = findViewById(R.id.btnDesactivar);
        Button btnActivar = findViewById(R.id.btnActivar);
        Button btnBack = findViewById(R.id.btnBack);

        // Configurar listeners
        btnAceptar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nombre = etNombre.getText().toString();
                String ciudad = etCiudad.getText().toString();
                String mensaje = "Usted se llama " + nombre + " y vive en " + ciudad + ".";
                tvFrase.setText(mensaje);
            }
        });

        btnDesactivar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                etNombre.setEnabled(false);
                etCiudad.setEnabled(false);
            }
        });

        btnActivar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                etNombre.setEnabled(true);
                etCiudad.setEnabled(true);
            }
        });

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}