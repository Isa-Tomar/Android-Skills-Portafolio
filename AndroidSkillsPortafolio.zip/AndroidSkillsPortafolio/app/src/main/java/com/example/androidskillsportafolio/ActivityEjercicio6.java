package com.example.androidskillsportafolio;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class ActivityEjercicio6 extends AppCompatActivity {

    private EditText etPrimerSemestre, etSegundoSemestre, etTercerSemestre;
    private TextView tvNotaFinal, tvResultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ejercicio6);

        // Inicializar vistas
        etPrimerSemestre = findViewById(R.id.etPrimerSemestre);
        etSegundoSemestre = findViewById(R.id.etSegundoSemestre);
        etTercerSemestre = findViewById(R.id.etTercerSemestre);
        tvNotaFinal = findViewById(R.id.tvNotaFinal);
        tvResultado = findViewById(R.id.tvResultado);
        Button btnCalcular = findViewById(R.id.btnCalcular);
        Button btnBack = findViewById(R.id.btnBack);

        // Configurar listeners
        btnCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calcularPromedio();
            }
        });

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private void calcularPromedio() {
        try {
            // Validar campos vacíos
            if (etPrimerSemestre.getText().toString().isEmpty() ||
                    etSegundoSemestre.getText().toString().isEmpty() ||
                    etTercerSemestre.getText().toString().isEmpty()) {
                Toast.makeText(this, "Por favor complete todas las notas", Toast.LENGTH_SHORT).show();
                return;
            }

            // Obtener valores
            double n1 = Double.parseDouble(etPrimerSemestre.getText().toString());
            double n2 = Double.parseDouble(etSegundoSemestre.getText().toString());
            double n3 = Double.parseDouble(etTercerSemestre.getText().toString());

            // Validar rango de notas (0-10)
            if (n1 < 0 || n1 > 10 || n2 < 0 || n2 > 10 || n3 < 0 || n3 > 10) {
                Toast.makeText(this, "Las notas deben estar entre 0 y 10", Toast.LENGTH_SHORT).show();
                return;
            }

            // Calcular promedio
            double promedio = (n1 + n2 + n3) / 3;
            String promedioFormateado = String.format("%.2f", promedio);

            // Mostrar resultados
            tvNotaFinal.setText("Nota Final: " + promedioFormateado);

            if (promedio < 5) {
                tvResultado.setText("NO APROBADO");
                tvResultado.setTextColor(Color.RED);
                tvNotaFinal.setTextColor(Color.RED);
            } else {
                tvResultado.setText("APROBADO");
                tvResultado.setTextColor(Color.GREEN);
                tvNotaFinal.setTextColor(Color.BLACK);
            }

        } catch (NumberFormatException e) {
            Toast.makeText(this, "Ingrese valores numéricos válidos", Toast.LENGTH_SHORT).show();
        }
    }
}