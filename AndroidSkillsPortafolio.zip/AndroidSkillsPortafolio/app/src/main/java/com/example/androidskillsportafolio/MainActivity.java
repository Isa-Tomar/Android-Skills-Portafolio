package com.example.androidskillsportafolio;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Configurar botones para cada ejercicio
        setupButton(R.id.btnEjercicio1, ActivityEjercicio1.class);
        setupButton(R.id.btnEjercicio2, ActivityEjercicio2.class);
        setupButton(R.id.btnEjercicio3, ActivityEjercicio3.class);
        setupButton(R.id.btnEjercicio4, ActivityEjercicio4.class);
        setupButton(R.id.btnEjercicio5, ActivityEjercicio5.class);
        setupButton(R.id.btnEjercicio6, ActivityEjercicio6.class);
        setupButton(R.id.btnEjercicio7, ActivityEjercicio7.class);
        setupButton(R.id.btnEjercicio8, ActivityEjercicio8.class);
        setupButton(R.id.btnEjercicio9, ActivityEjercicio9.class);
        setupButton(R.id.btnEjercicio10, ActivityEjercicio10.class);

    }

    private void setupButton(int buttonId, final Class<?> activityClass) {
        Button button = findViewById(buttonId);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, activityClass));
            }
        });
    }
}