package com.example.androidskillsportafolio;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class ActivityEjercicio5 extends AppCompatActivity {

    private EditText etUnidades, etPrecio;
    private TextView tvTotalSinIva, tvIva, tvTotalConIva;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ejercicio5);

        // Inicializar vistas
        etUnidades = findViewById(R.id.etUnidades);
        etPrecio = findViewById(R.id.etPrecio);
        tvTotalSinIva = findViewById(R.id.tvTotalSinIva);
        tvIva = findViewById(R.id.tvIva);
        tvTotalConIva = findViewById(R.id.tvTotalConIva);
        Button btnCalcular = findViewById(R.id.btnCalcular);
        Button btnBack = findViewById(R.id.btnBack);

        // Configurar listeners
        btnCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calcularTotal();
            }
        });

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private void calcularTotal() {
        try {
            // Obtener valores de los campos
            int unidades = Integer.parseInt(etUnidades.getText().toString());
            double precio = Double.parseDouble(etPrecio.getText().toString());

            // Realizar cálculos
            double totalSinIva = unidades * precio;
            double iva = totalSinIva * 0.16;
            double totalConIva = totalSinIva + iva;

            // Mostrar resultados
            tvTotalSinIva.setText(String.format("Total sin IVA: $%.2f", totalSinIva));
            tvIva.setText(String.format("IVA (16%%): $%.2f", iva));
            tvTotalConIva.setText(String.format("Total con IVA: $%.2f", totalConIva));

        } catch (NumberFormatException e) {
            Toast.makeText(this, "Por favor ingrese valores válidos", Toast.LENGTH_SHORT).show();
        }
    }
}